const cartService = require('../services/cartService');

class CartController {

}

module.exports = new CartController();